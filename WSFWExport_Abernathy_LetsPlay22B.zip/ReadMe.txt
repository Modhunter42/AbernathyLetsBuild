EDIT: Added Differential files (made from Slightly different log files), no profiles.
I suspect this is easier (at least for the sniper nest that had power line edits in the log file with it)



Edit that replaces the bridge with the Nav-meshed version.
Works great. Settlers use it by themselves.

Second edit then changes the door in the bunkhouse from the one with barbed-wire poles to same doorway without them. It would annoy you/others when building on the 2nd floor.  Strangely the regular doorways (2) are at the End of the long list of walls, while the one with the barbeded-wire poles is at the Start.

Also please (manually) Scrap the cutoff switch in the windmill tower. Power will still be connected.

Further testing in progress...

Now that the Video is out & I've Seen what you did and heard your plans....

3rd Export
Added a little edit to change the stairs to be more uniform. Oddly 'shack stairs' and 'shack stairs half' (both Vanilla) are not the same size so I had to enlarge & then Nav-Mesh it but it looks fine and works well.

4th Export
Removed the Windmills & bits on the tower

5th Export
Replaced Windmills with Version 2.7 and then tweaked it a bit to fit in.

6th Export
Edits to the new SniperTowerNest. Added some Ammo & Rifle. Added a bed (so somebody hangs out there at night) with a strong box in the corner.  Added a Net for Camoflage/Cover on the North side.
Then I fiddled with the power connections, which I Should have done in a Separate export.