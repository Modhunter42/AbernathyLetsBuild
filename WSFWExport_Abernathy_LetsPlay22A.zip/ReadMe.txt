Edit that replaces the bridge with the Nav-meshed version.
Works great. Settlers use it by themselves.

Second edit then changes the door in the bunkhouse from the one with barbed-wire poles to same doorway without them. It would annoy you/others when building on the 2nd floor.  Strangely the regular doorways (2) are at the End of the long list of walls, while the one with the barbeded-wire poles is at the Start.

Also please (manually) Scrap the cutoff switch in the windmill tower. Power will still be connected.

Further testing in progress...